from kafka import KafkaProducer
import time
import socket
import os
import pandas as pd

bootstrap_servers = "localhost:9092"
topic = 'adjectives'
time_interval = 1

directory_path = "google_books_data"
all_files = os.listdir(directory_path)
file_names = [f for f in all_files if os.path.isfile(os.path.join(directory_path, f))]

producer = KafkaProducer(bootstrap_servers=bootstrap_servers)

print(f"Streaming Topic: {topic} >>> \n")
for file in file_names:
    df = pd.read_csv(directory_path + '/' + file)
    df = df[df['part_of_speech'] == 'adjektif']

    for idx, row in df.iterrows():
        message = f"Row {idx}: Vocab: {row['vocab']}, POS: {row['part_of_speech']}"
        producer.send(topic, value=message.encode('utf-8'))
        print(f"Sent: {message}")
        time.sleep(time_interval)
        
shutdown_signal = "SHUTDOWN"
producer.send(topic, value=shutdown_signal.encode('utf-8'))

producer.flush()
print(f"Data Topic {topic} Streamed Successfully!\n\n")