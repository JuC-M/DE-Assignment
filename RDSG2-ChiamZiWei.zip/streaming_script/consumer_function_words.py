from kafka import KafkaConsumer
import time
import socket

bootstrap_servers = "localhost:9092"
topic = 'functionWords'

consumer = KafkaConsumer(topic,bootstrap_servers=bootstrap_servers)

for msg in consumer:
    if msg.value == b'SHUTDOWN':
        print("Received shutdown signal. Terminating consumer...")
        consumer.close()
        break
        
    print(msg)

consumer.close()
print(f"Consumer {topic} Terminated Successfully!\n\n")