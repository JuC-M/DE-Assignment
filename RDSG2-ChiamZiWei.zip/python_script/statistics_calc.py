import scipy.stats

def mean(l: list):
    return sum(l) / len(l)

def var(l: list):
    ssx = sum([x ** 2 for x in l])
    sx = sum(l)
    n = len(l)

    return (ssx - sx ** 2/n)/(n-1)

def stddev(l: list):
    return var(l) ** 0.5

def stderr(l: list):
    return stddev(l) / (len(l)**0.5)
    
def val_range(l: list):
    return (max(l) - min(l))

def cor(l: list):
    return val_range(l)/(max(l) + min(l))

def conf_int(l: list, alpha: float):
    if len(l) >= 30:
        crit_v = scipy.stats.norm.ppf(1 - alpha)
        std_err = stderr(l)
    else:
        crit_v = scipy.stats.t.ppf(1 - alpha, df=len(l) - 1)
        std_err = stderr(l)

    return (round(float(mean(l) - crit_v * std_err), 4), round(float(mean(l) + crit_v * std_err), 4))