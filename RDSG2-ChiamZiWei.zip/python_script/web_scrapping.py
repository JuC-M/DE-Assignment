import requests
from bs4 import BeautifulSoup as bs
import sys, os

class Word:

    def __init__(self, keyword):
        self.keyword = keyword
        self.lexicon = []
        self.definition_str = ''

    def getKeyword(self):
        return self.keyword

    def getLexicon(self):
        return self.lexicon

    def getDefinitionStr(self):
        return self.definition_str
    
    def extractLexicon(self):
        try:
            r = requests.get(f"https://prpm.dbp.gov.my/cari1?keyword={self.keyword}")
            soup = bs(r.content, 'html.parser')
            word_length = len(self.keyword)
            
            definition_soup = soup.find('div', class_='tab-pane fade in active')
            
            try:
                definition_soup.font.decompose()
            except:
                pass

            try:
                self.definition_str = definition_soup.get_text()
            except:
                pass
            
            def_list = []
            eg_list = []

            if self.definition_str.find('1') != -1:
                i = 1
                while True:
                    try:
                        def_start_index = self.definition_str.index(f'{i:.0f}')
                        def_end_index = len(self.definition_str[:def_start_index]) + self.definition_str[def_start_index:].index(':')
                        
                        eg_start_index = len(self.definition_str[:def_start_index]) + self.definition_str[def_start_index:].index(':')
                        eg_end_index = len(self.definition_str[:eg_start_index]) + self.definition_str[eg_start_index:].index(';')
                    
                        def_temp = self.definition_str[def_start_index:def_end_index].replace(': ', '')
                        eg_temp = f'{i}. ' + self.definition_str[eg_start_index+2:eg_end_index].replace('~', self.keyword)
                
                        while def_temp.find('\xad') != -1:
                            def_temp = def_temp.replace('\xad', '')
                        while eg_temp.find('\xad') != -1:
                            eg_temp = eg_temp.replace('\xad', '')
                
                        def_list.append(def_temp)
                        eg_list.append(eg_temp)
                        i += 1
                    except Exception as e:
                        break
            else:
                try:
                    def_start_index = self.definition_str.index(f'Definisi :')
                    def_end_index = len(self.definition_str[:def_start_index]) + self.definition_str[def_start_index:].index(':')
                        
                    eg_start_index = len(self.definition_str[:def_start_index]) + self.definition_str[def_start_index:].index(':')
                    eg_end_index = len(self.definition_str[:eg_start_index]) + self.definition_str[eg_start_index:].index('.')
                    
                    def_temp = self.definition_str[def_start_index:def_end_index].replace(': ', '')
                    eg_temp = f'{i}. ' + self.definition_str[eg_start_index+2:eg_end_index].replace('~', self.keyword)
                
                    while def_temp.find('\xad') != -1:
                        def_temp = def_temp.replace('\xad', '')
                    while eg_temp.find('\xad') != -1:
                        eg_temp = eg_temp.replace('\xad', '')
                
                    def_list.append(def_temp)
                    eg_list.append(eg_temp)
                except:
                    pass

            part_of_speech = ''
            synonyms = []
            derived_words = []
            
            try:
                thesaurus_soup = soup.find('span', id='MainContent_SearchInfoTesaurus_lblTesaurus')
                thesaurus_str = thesaurus_soup.get_text()
                
                pos_start_index = thesaurus_str.index('(')
                pos_end_index = thesaurus_str.index(')')
                part_of_speech = thesaurus_str[pos_start_index+1:pos_end_index]
                
                thesaurus_str = thesaurus_str.replace(thesaurus_str[:pos_end_index+1], '')
                synonyms_str = thesaurus_str[:thesaurus_str.index('Kata Terbitan')]
                derived_words_str = thesaurus_str[thesaurus_str.index('Kata Terbitan : ') + 16:]
        
                i = 1
                while True:
                    try:
                        synonym_start_index = synonyms_str.index(f'{i}. Bersinonim dengan ')
                        
                        if synonyms_str.find(f'{i+1}.') != -1:   
                            synonym_end_index = synonyms_str.index(f'{i+1}.')
                
                            synonym_pure = synonyms_str[synonym_start_index+21:synonym_end_index].replace('\n', '')
                
                            synonym_pure = synonym_pure.replace(':', ',')
                            splitted_synonym = synonym_pure.split(', ')
                
                            for i in range(len(splitted_synonym) - 1):
                                synonyms.append(splitted_synonym[i])
                
                            synonyms_str = synonyms_str.replace(synonyms_str[synonym_start_index:synonym_end_index], '')
                        else:
                            synonym_pure = synonyms_str[synonym_start_index+21:].replace('\n','')
                            
                            synonym_pure = synonym_pure.replace(':', ',')
                            splitted_synonym = synonym_pure.split(', ')
                
                            for i in range(len(splitted_synonym) - 1):
                                synonyms.append(splitted_synonym[i])
                
                        i += 1
                    except:
                        break
        
                while True:
                    try:
                        splitted_derived_words = derived_words_str.split(', ')
                        
                        for i in range(len(splitted_derived_words) - 1):
                            derived_words.append(splitted_derived_words[i])
                        break
                    except:
                        break
            except:
                pass

            try:
                self.lexicon.append(self.keyword)
                self.lexicon.append(word_length)
                self.lexicon.append(part_of_speech)
                self.lexicon.append(def_list)
                self.lexicon.append(eg_list)
                self.lexicon.append(synonyms)
                self.lexicon.append(derived_words)
            except:
                pass
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)