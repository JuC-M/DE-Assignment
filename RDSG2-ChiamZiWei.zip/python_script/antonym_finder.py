import re
import requests
import string
from bs4 import BeautifulSoup as bs

def findAntonym(word: str):
    r = requests.get(f"https://prpm.dbp.gov.my/cari1?keyword={word}")
    soup = bs(r.content, 'html.parser')

    try:
        thesaurus_soup = soup.find('span', id='MainContent_SearchInfoTesaurus_lblTesaurus')

        if thesaurus_soup:
            thesaurus_str = thesaurus_soup.get_text()
            thesaurus_str = re.sub('\d', ' ', thesaurus_str)

            try:
                derived_word_index = thesaurus_str.index('Kata Terbitan')
                thesaurus_str = thesaurus_str[:derived_word_index]
            except:
                pass

            antonym_list = []
            while thesaurus_str.find('Berantonim dengan') != -1:
                match = re.search(r'Berantonim dengan (\w+)', thesaurus_str)
                if match:
                    antonym_index = thesaurus_str.index('Berantonim dengan')
                    antonym = match.group(1)
    
                    thesaurus_str = thesaurus_str[antonym_index+17:]
                    antonym_list.append(antonym)

        return ';'.join(antonym_list)
    except:
        return ''