import pandas as pd
from pyspark.sql import DataFrame
from rapidfuzz import fuzz
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def merge_dfs(df_base, df_com):
    if isinstance(df_base, DataFrame):
        df_base = df_base.toPandas()

    if isinstance(df_com, DataFrame):
        df_com = df_com.toPandas()

    merged_df = pd.merge(df_base, df_com, left_on=df_base.columns[0], right_on=df_com.columns[0], how='left', suffixes=('_base', '_com'))
    return merged_df, df_base, df_com
    
def coverage(df_base, df_com):
    merged_df, df_base, df_com = merge_dfs(df_base, df_com)

    total_base_words = len(df_base)
    overlapping_words = merged_df['definitions_com'].notna().sum()
    return overlapping_words / total_base_words

def annotation_accuracy_exact(df_base, df_com):
    merged_df, df_base, df_com = merge_dfs(df_base, df_com)
    
    merged_df['exact_match'] = merged_df.apply(
        lambda row: 1 if row['definitions_base'] == row['definitions_com'] else 0, axis=1
    )
    
    exact_accuracy = merged_df['exact_match'].mean()
    return exact_accuracy

def similarity_levenshtein(df_base, df_com):
    merged_df, df_base, df_com = merge_dfs(df_base, df_com)
    
    merged_df['similarity'] = merged_df.apply(
        lambda row: fuzz.ratio(str(row['definitions_base']), str(row['definitions_com'])), axis=1
    )
    
    average_similarity = merged_df['similarity'].mean()
    return average_similarity