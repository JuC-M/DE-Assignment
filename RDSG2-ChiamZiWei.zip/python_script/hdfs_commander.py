import subprocess

def run_hdfs_command(command):
    try:
        # Run the HDFS command using subprocess
        result = subprocess.run(command, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        # Capture the standard output and error (if any)
        output = result.stdout.decode('utf-8')
        error = result.stderr.decode('utf-8')
        
        if output:
            print("Output:", output)
        if error:
            print("Error:", error)
    except subprocess.CalledProcessError as e:
        print(f"Error occurred: {e}")