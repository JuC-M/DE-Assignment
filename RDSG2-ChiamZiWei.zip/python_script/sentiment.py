from textblob import TextBlob
from deep_translator import GoogleTranslator

def translateFromMyToEn(s):
    translated_s = GoogleTranslator(source='ms', target='en').translate(s)
    return translated_s

def getPolarityValue(s):
    return TextBlob(s).sentiment.polarity
    
def getPolarityOf(s):
    pol = getPolarityValue(s)

    if pol < 0:
        return 'negative'
    elif pol == 0:
        return 'none'
    else:
        return 'positive'

def getSubjectivityValue(s):
    return TextBlob(s).sentiment.subjectivity

def getSubjectivityFrom(val):
    if val >= 0 and val < 0.25:
        return 'fact-driven'
    elif val >= 0.25 and val < 0.5:
        return 'partially fact-driven'
    elif val >= 0.5 and val < 0.75:
        return 'partially opinion-driven'
    else:
        return 'opinion-driven'
        
def getSubjectivityOf(s):
    sub = getSubjectivityValue(s)

    return getSubjectivityFrom(sub)