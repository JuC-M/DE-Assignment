import requests
from datetime import datetime

def scrapeWith(query, max_result=1, year=None):
    if len(str(year)) != 4:
        raise ValueError('Please Provide year in 4 digits (e.g.: 2024)')
    
    url = "https://www.googleapis.com/books/v1/volumes"
    
    params = {
        'q': query,
        'langRestrict': 'my'
    }
    
    response = requests.get(url, params=params)

    book_info = []
    if response.status_code == 200:
        data = response.json()
        
        if 'items' in data:
            for i, book in enumerate(data['items']):
                # Stop scraping if we've reached the max_result
                if i >= max_result:
                    break

                description = book['volumeInfo'].get('description', 'No description available')
                if description != 'No description available':
                    title = book['volumeInfo'].get('title', 'No title available')
                    authors = book['volumeInfo'].get('authors', ['No authors available'])
                    publisher = book['volumeInfo'].get('publisher', 'No publisher available')
                    link = book['volumeInfo'].get('infoLink', 'No link available')
                    published_date = book['volumeInfo'].get('publishedDate', None)

                    if year:
                        if published_date and published_date.startswith(str(year)):
                            book_info.append([title, authors, publisher, description, link, published_date])
                    else:
                        book_info.append([title, authors, publisher, description, link, published_date])

        else:
            print("No books found.")
    else:
        print("Failed to retrieve data:", response.status_code)

    return book_info