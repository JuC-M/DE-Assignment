#!/bin/sh

cd ~/DE-Assignment

python streaming_script/producer_nouns.py
echo -n
python streaming_script/producer_verbs.py
echo -n
python streaming_script/producer_function_words.py
echo -n
python streaming_script/producer_adverbs.py
echo -n
python streaming_script/producer_adjectives.py
echo -n
