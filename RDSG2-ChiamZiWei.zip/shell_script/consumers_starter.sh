#!/bin/sh

cd ~/DE-Assignment

python streaming_script/consumer_nouns.py
echo -n
python streaming_script/consumer_verbs.py
echo -n
python streaming_script/consumer_function_words.py
echo -n
python streaming_script/consumer_adverbs.py
echo -n
python streaming_script/consumer_adjectives.py
echo -n
